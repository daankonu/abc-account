* Benjamin Willig <benjamin.willig@acsone.eu>
* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>

* Pierre Verkest <pierreverkest84@gmail.com>
* Manuel Regidor <manuel.regidor@sygel.es>
