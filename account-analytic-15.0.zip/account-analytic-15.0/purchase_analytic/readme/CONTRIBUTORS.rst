* Laetitia Gangloff <laetitia.gangloff@acsone.eu>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Pimolnat Suntian <pimolnats@ecosoft.co.th>
* `Jarsa <https://www.jarsa.com>`_

  * Alan Ramos
