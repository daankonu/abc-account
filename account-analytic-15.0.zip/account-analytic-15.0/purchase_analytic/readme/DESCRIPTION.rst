The goal of this module is to ease analytic account management on purchase order.
This module add analytic account on purchase order.

If all lines of the purchase order have the same analytic account, the analytic account on the purchase order is automatically set with this value.
If a analytic account is set on the purchase order, all lines of the purchase will take this value.
