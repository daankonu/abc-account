Set default default tags on analytic accounts that apply to invoices when no
other tag is specified and when changing the analytic account.
