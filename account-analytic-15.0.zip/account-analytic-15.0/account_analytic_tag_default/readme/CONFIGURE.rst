Go to an analytic account and set *Default Analytic Tags*.
