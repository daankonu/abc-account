Go to an invoice and select a analytic account in a line, default tags for the
account are automatically applied.
