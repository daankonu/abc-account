#. Add any product with *Make To Order* option enabled into a new sale order.
#. Set *Analytic Account*.
#. *Confirm Sale*
#. The generated purchase order line will have this analytic account.
   They won't be grouped if analytic account is different.
