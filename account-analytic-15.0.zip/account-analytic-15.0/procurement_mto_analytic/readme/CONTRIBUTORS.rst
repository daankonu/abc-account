* `Tecnativa <https://www.tecnativa.com>`__:

  * Carlos Dauden
  * Pedro M. Baeza
  * Vicent Cubells

* Ventor-Tech:

  * Sergej Lozikov

* `Komit <https://komit-consulting.com/>`__:

  * Duc, Dao Dong <duc.dd@komit-consulting.com>

* `Ecosoft <https://ecosoft.co.th/>`__:

  * Pimolnat Suntian <pimolnats@ecosoft.co.th>

* `Jarsa <https://www.jarsa.com/>`__:

  * Alan Ramos <alan.ramos@jarsa.com>
