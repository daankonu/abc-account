13.0.1.0.0 (2020-01-08)
~~~~~~~~~~~~~~~~~~~~~~~

Migrated to odoo 13.

12.0.1.0.1 (2019-02-19)
~~~~~~~~~~~~~~~~~~~~~~~

[ADD] Add feature to set analytic account for purchase lines of service products.

12.0.1.0.0 (2019-02-18)
~~~~~~~~~~~~~~~~~~~~~~~

Migrated to odoo 12.

11.0.1.0.0 (2018-11-15)
~~~~~~~~~~~~~~~~~~~~~~~

First version.
